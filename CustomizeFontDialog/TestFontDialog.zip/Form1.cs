﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestFontDialog
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnChangeFont_Click(object sender, EventArgs e)
        {
            var fontDialog = new FontDialog();

            fontDialog.Font = CreateDefaultFont();

            if (fontDialog.ShowDialog() == DialogResult.OK)
            {
                lblFontSample.Font = fontDialog.Font;

                lblFontName.Text = fontDialog.Font.Name;
                lblFontFamily.Text = fontDialog.Font.FontFamily.Name.ToString();
                lblFontSize.Text = fontDialog.Font.Size.ToString();
                lblFontStyle.Text = fontDialog.Font.Style.ToString();
            }
        }

        private Font CreateDefaultFont()
        {
            return new Font("Tahoma", 10, FontStyle.Bold);
        }
    }
}
