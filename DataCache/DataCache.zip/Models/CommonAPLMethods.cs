﻿using System;
using System.Collections.Generic;

namespace DataCache
{
    public class CommonAPLMethods
    {
        public List<DeactiveItemRoot> GetDeactiveRoot(bool v1, bool v2)
        {
            System.Threading.Thread.Sleep(5000);
            return new List<DeactiveItemRoot>();
        }
    }
}