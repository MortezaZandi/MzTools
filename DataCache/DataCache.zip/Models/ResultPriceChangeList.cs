﻿namespace DataCache
{
    public class ResultPriceChangeList
    {
    }
}