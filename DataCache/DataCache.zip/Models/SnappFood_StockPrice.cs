﻿namespace DataCache
{
    public class SnappFood_StockPrice
    {
    }
}