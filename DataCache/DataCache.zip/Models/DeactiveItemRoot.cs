﻿namespace DataCache
{
    public class DeactiveItemRoot
    {
        public int Id { get; internal set; }
        public int RetailStoreID { get; internal set; }
    }
}