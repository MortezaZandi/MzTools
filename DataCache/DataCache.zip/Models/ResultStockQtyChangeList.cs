﻿namespace DataCache
{
    public class ResultStockQtyChangeList
    {
    }
}